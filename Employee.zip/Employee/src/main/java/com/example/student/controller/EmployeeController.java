package com.example.student.controller;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.student.model.EmployeeModel;
import com.example.student.service.EmployeeService;


@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService service;
	
	@GetMapping("/findAllEmployee")
	public ArrayList<EmployeeModel> findAll(){
    ArrayList<EmployeeModel> list=service.findall();
    ArrayList sortedList=new ArrayList();
    for(int i=0;i<list.size();i++) {
    	sortedList.add(list.get(i).getName());
    }
    Collections.sort(sortedList);
	return sortedList;
	}
}
	
	